module.exports = {
  googleClientID: '860944633839-lv66uhdpfsaem0i4evqlgl9anddebo8o.apps.googleusercontent.com',
  googleClientSecret: '0OzXmticI5cthLTGhoUvZdBF',
  mongoURI: 'mongodb://animeshk55:Animinchinmamta@k55@ds121955.mlab.com:21955/diwali-server-database'
};
